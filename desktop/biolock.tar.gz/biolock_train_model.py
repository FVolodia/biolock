import os
import numpy as np
import skflow
from sklearn import metrics


BASIC_DIR = os.path.dirname(os.path.realpath(__file__))
ECG_DATA_DIR = os.path.join(BASIC_DIR, 'ecg_data')
PARTICIPANT_LIST = ['non-user2', 'user']
ECG_SEGMENT_LENGTH = 270


def load_ecg_features(ecg_data_directory, participant_list):
    data_set_dict = dict()
    for participant_name in participant_list:
        participant_directory = os.path.join(ecg_data_directory, participant_name)
        file_list = os.listdir(participant_directory)
        records_num = len(file_list)
        ecg_features = np.zeros([records_num, ECG_SEGMENT_LENGTH])
        for i in xrange(records_num):
            print i
            # reading data from file
            file_path = os.path.join(participant_directory, file_list[i])
            ecg_features_vec = np.loadtxt(file_path)
            # combining feature vectors to matrix
            ecg_features[i, :] = ecg_features_vec[:]
        # add to dictionary features from new record
        data_set_dict[participant_name] = ecg_features

    ecg_features_path = os.path.join(ecg_data_directory, 'ecg_features.npz')
    np.savez(ecg_features_path, **data_set_dict)
    ecg_features = np.load(ecg_features_path)
    labels = ecg_features.files
    num_class = len(labels)
    ecg_segment_length = ecg_features[labels[0]].shape[1]
    ecg_targets = np.zeros([0, num_class])
    ecg_inputs = np.zeros([0, ecg_segment_length])

    for i in xrange(num_class):
        participant_name = labels[i]
        class_inputs = ecg_features[participant_name]
        num_records = class_inputs.shape[0]
        class_targets = np.zeros([num_records])
        class_targets[:] = i  # set true index for current class
        ecg_inputs = np.vstack([ecg_inputs, class_inputs])
        ecg_targets = np.append(ecg_targets, class_targets)

    return ecg_targets, ecg_inputs, labels


def randomize_features(targets, inputs):
    num_records = targets.shape[0]
    rand_ind = np.random.permutation(num_records)
    # rand_ind = np.random.randint(num_records)
    targets_rand = targets[rand_ind]
    inputs_rand = inputs[rand_ind]
    # ecg_targets_rand = np.random.shuffle(ecg_targets)
    return targets_rand, inputs_rand


def split_features(targets, inputs):
    num_records = targets.shape[0]
    num_records_train = np.round(num_records*0.7)
    train_targets = targets[:num_records_train]
    train_inputs = inputs[:num_records_train]
    test_targets = targets[num_records_train:]
    test_inputs = inputs[num_records_train:]
    return train_targets, train_inputs, test_targets, test_inputs


def main():
    # prepare train and test sets
    ecg_data_directory = os.path.join(BASIC_DIR, ECG_DATA_DIR)
    ecg_targets, ecg_inputs, labels = load_ecg_features(ecg_data_directory, PARTICIPANT_LIST)
    ecg_targets, ecg_inputs = randomize_features(ecg_targets, ecg_inputs)
    train_targets, train_inputs, test_targets, test_inputs = split_features(ecg_targets, ecg_inputs)

    # build 3 layer DNN with 10, 20, 10 units respectively
    num_classes = len(labels)
    layers = [70, 50, 50, 30, 20]
    num_epochs = 1000
    classifier = skflow.TensorFlowDNNClassifier(hidden_units=layers, n_classes=num_classes, steps=num_epochs)

    # fit model
    print "  "
    print "Displaying DNN training flow:"
    classifier.fit(train_inputs, train_targets)

    # accuracy evaluation
    score = metrics.accuracy_score(test_targets, classifier.predict(test_inputs))
    print('Accuracy: {0:f}'.format(score))

    # save model
    model_path = os.path.join(BASIC_DIR, 'dnn_model')
    if not os.path.exists(model_path):
        os.makedirs(model_path)
    bias = np.asarray(classifier.bias_)
    weights = np.asarray(classifier.weights_)
    n_layers = len(weights)
    for l in range(0, n_layers):
        filename = 'bias_weights_%i.csv' % l
        file_path = os.path.join(model_path, filename)
        w = np.vstack([bias[l], weights[l]])
        np.savetxt(file_path, w, delimiter=',')

if __name__ == '__main__':
    main()
